import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message)
{   
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.setStringProperty("These iFLOWS will be Deployed","These iFLOWS will be Deployed")
        messageLog.addAttachmentAsString("These iFLOWS will be Deployed",body,"text/plain");
    }
    return message;
}