import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    def json = new JsonSlurper().parseText(message.getBody(String));
    //message.setHeader('access_token',
    
    String artifact_list = '<ROOT>';
    for(int i=0; i< json.d.results.size(); i++)
    {   
        if(json.d.results[i].Id.toString() != 'Tenant_Management_iFLOW')
        {
            artifact_list = artifact_list+'\n'+'<Record>';
        artifact_list = artifact_list+'\n'+'<Artifact>'+json.d.results[i].Id.toString()+'</Artifact>';
           artifact_list = artifact_list+'\n'+'<Artifact_Type>'+json.d.results[i].Type.toString()+'</Artifact_Type>';
           
            artifact_list = artifact_list+'\n'+'</Record>';
        }
    }
    artifact_list = artifact_list+'\n</ROOT>';
    message.setBody(artifact_list);
    return message;


}